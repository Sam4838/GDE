﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SMC.Models;

namespace SMC.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        smcEntities db = new smcEntities();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            return RedirectToAction("CreateMsg");
        }

        public ActionResult CreateMsg()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateMsg(MessageTbl msg)
        {

                db.MessageTbls.Add(msg);
                db.SaveChanges();
            
            return RedirectToAction("GetMsg");
        }

        public ActionResult GetMsg()
        {
            var msg = db.MessageTbls.ToList();
            return View(msg);
        }


        public ActionResult ViewAds()
        {
            var adsList = db.AdvertiseTbls.ToList();
            return View(adsList);
        }



    }
}