﻿using SMC.Models;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;

namespace SMC.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        // GET: Account
        smcEntities db = new smcEntities();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Login(RegistrationTbl registration)
        {
            var count = db.RegistrationTbls.Where(x => x.UserName == registration.UserName && x.Password == registration.Password).Count();
            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(registration.UserName, false);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["InvalidMsg"] = "User Name OR Password is incorrect";
                return View();

            }

        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index","Home");

        }

        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignUp(RegistrationTbl registration, string IsAgreeTerms)

         {

            if (IsAgreeTerms == "true")
            {
                registration.IsAgreeTerms = true;
            }
            else
            {
                registration.IsAgreeTerms = false;

            }


            if (registration.UserImageFile == null)
            {
                //registration.ProfileImgPath = "~/uploads/notAvlImage.jpg";
                registration.ProfileImgPath = null;
            }
            else
            {

                string fileName = Path.GetFileNameWithoutExtension(registration.UserImageFile.FileName);
                string extension = Path.GetExtension(registration.UserImageFile.FileName);
                fileName = fileName + DateTime.Now.ToString("mmyyssff") + extension;
                registration.ProfileImgPath = "~/uploads/" + fileName;
                fileName = Path.Combine(Server.MapPath("~/uploads/"), fileName);
                registration.UserImageFile.SaveAs(fileName);

            }

            db.RegistrationTbls.Add(registration);
            db.SaveChanges();

            return RedirectToAction("Login");
        }
        //[HttpPost]

        public JsonResult IsUserExists(string userdata)
        {

            System.Threading.Thread.Sleep(200);
                var searchData = db.RegistrationTbls.Where(x => x.UserName == userdata).SingleOrDefault();
            if (searchData!=null)
            {
                return Json(1);
            }
            else
            {
                return Json(0);
            }
            //check if any of the UserName matches the UserName specified in the Parameter using the ANY extension method.  
            //return Json(!db.RegistrationTbls.Any(x => x.UserName == UserName), JsonRequestBehavior.AllowGet);
        }
        //public JsonResult CheckUser(string userName)
        //{
        //    bool result = !db.RegistrationTbls.ToList().Exists(model => model.UserName.Equals(userName, StringComparison.CurrentCultureIgnoreCase));
        //    return Json(result);
        //}

        public ActionResult ForgotPwd(RegistrationTbl registration, string usrName)
        {


            return View();
        }


    }
}