﻿using SMC.Models;
using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace SMC.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        smcEntities db = new smcEntities();
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult GetUsersList()
        {
            var getUsers = db.RegistrationTbls.ToList();
            return View(getUsers);
        }

        public ActionResult GetUserSms()
        {
            var getUserTextMsg = db.MessageTbls.ToList();

            foreach (var item in getUserTextMsg)
            {

                TempData["SenderId"] = item.MsgId;
                TempData["SenderName"] = item.FullName;
                TempData["SenderEmail"] = item.Email;
                TempData["SenderMessage"] = item.Message;
                

            }

            return View();
        }

        public ActionResult GetAdsList(AdvertiseTbl advertise)
        {

            //var getAdvertiseList = db.AdvertiseTbls.ToList();

            if (advertise.AdsFilePath == null)
            {
                advertise.AdsFilePath = "~/uploads/notAvlImage.jpg";
            }



            return View(db.AdvertiseTbls.ToList());
        }
        public ActionResult CreateAds()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateAds(AdvertiseTbl advertise)
        {


            if (advertise.AdsImageFile != null)
            {

                string fileName = Path.GetFileNameWithoutExtension(advertise.AdsImageFile.FileName);
                string extension = Path.GetExtension(advertise.AdsImageFile.FileName);
                fileName = fileName + DateTime.Now.ToString("mmyyssff") + extension;
                advertise.AdsFilePath = "~/uploads/" + fileName;
                fileName = Path.Combine(Server.MapPath("~/uploads/"), fileName);
                advertise.AdsImageFile.SaveAs(fileName);

                //advertise.AdsFilePath = "~/uploads/notAvlImage.jpg";
            }
            else
            {

                advertise.AdsFilePath = null;

            }


            db.AdvertiseTbls.Add(advertise);
            db.SaveChanges();




            return RedirectToAction("GetAdsList");
        }



    }
}